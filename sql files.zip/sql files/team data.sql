/*
-- Query: SELECT * FROM pokedex.team
LIMIT 0, 1000

-- Date: 2022-09-03 13:02
*/
INSERT INTO `` (`team_id`,`name`) VALUES (2,'Alakazam');
INSERT INTO `` (`team_id`,`name`) VALUES (4,'Gengar');
INSERT INTO `` (`team_id`,`name`) VALUES (1,'Heracross');
INSERT INTO `` (`team_id`,`name`) VALUES (5,'Mewtwo');
INSERT INTO `` (`team_id`,`name`) VALUES (3,'Tyranitar');
