CREATE TABLE `pokemon` (
  `pokemon_id` int NOT NULL,
  `name` varchar(45) NOT NULL,
  `type_1` varchar(15) NOT NULL,
  `type_2` varchar(15) DEFAULT '',
  `region` varchar(15) NOT NULL,
  `legendary` varchar(15) NOT NULL,
  PRIMARY KEY (`pokemon_id`),
  UNIQUE KEY `pokemon_id_UNIQUE` (`pokemon_id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `moves` (
  `move_id` int NOT NULL,
  `name` varchar(25) NOT NULL,
  `type` varchar(25) NOT NULL,
  `category` varchar(45) NOT NULL,
  PRIMARY KEY (`move_id`),
  UNIQUE KEY `move_id_UNIQUE` (`move_id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `team` (
  `team_id` int NOT NULL,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`team_id`),
  UNIQUE KEY `team_id_UNIQUE` (`team_id`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  CONSTRAINT `name` FOREIGN KEY (`name`) REFERENCES `pokemon` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `poke_moves` (
  `assign_id` int NOT NULL AUTO_INCREMENT,
  `move_name` varchar(25) NOT NULL,
  `pokemon_name` varchar(25) NOT NULL,
  PRIMARY KEY (`assign_id`),
  UNIQUE KEY `assign_id_UNIQUE` (`assign_id`),
  KEY `move_name_idx` (`move_name`),
  KEY `pokemon_name_idx` (`pokemon_name`),
  CONSTRAINT `move_name` FOREIGN KEY (`move_name`) REFERENCES `moves` (`name`),
  CONSTRAINT `pokemon_name` FOREIGN KEY (`pokemon_name`) REFERENCES `pokemon` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
