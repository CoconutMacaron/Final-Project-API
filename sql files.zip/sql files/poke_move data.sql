/*
-- Query: SELECT * FROM pokedex.poke_moves
LIMIT 0, 1000

-- Date: 2022-09-03 13:03
*/
INSERT INTO `` (`assign_id`,`move_name`,`pokemon_name`) VALUES (4,'Razor Leaf','Venusaur');
